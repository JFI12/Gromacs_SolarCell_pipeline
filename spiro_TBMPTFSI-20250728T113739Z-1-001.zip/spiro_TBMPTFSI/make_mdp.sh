cat > md.mdp <<EOF
; Production MD
integrator       = md
dt               = 0.002
nsteps           = 2500000       ; 5 ns (adjust as needed)
nstxout          = 1000
nstvout          = 1000
nstenergy        = 1000
nstlog           = 1000
nstxout-compressed = 500

continuation     = yes
constraint_algorithm = lincs
constraints      = h-bonds
lincs_iter       = 2
lincs_order      = 4

tcoupl           = V-rescale
tc-grps          = SPI     TBM   TFS
tau_t            = 0.1     0.1   0.1
ref_t            = 300     300   300

pcoupl           = Parrinello-Rahman
pcoupltype       = isotropic
tau_p            = 2.0
ref_p            = 1.0
compressibility  = 4.5e-5

gen_vel          = no

EOF



cat > minim.mdp <<EOF
integrator  = steep        ; Algorithm (steep = steepest descent minimization)
emtol       = 1000.0       ; Stop minimization when max force < 1000 kJ/mol/nm
emstep      = 0.01         ; Minimization step size
nsteps      = 50000        ; Maximum number of minimization steps

cutoff-scheme   = Verlet
coulombtype     = PME
rcoulomb        = 1.0
rvdw            = 1.0

pbc             = xyz
nstlist         = 10
ns_type         = grid
EOF


cat > npt.mdp <<EOF
; NPT equilibration
integrator       = md
dt               = 0.002
nsteps           = 1000000        ; 2 ns
nstxout          = 1000
nstvout          = 1000
nstenergy        = 1000
nstlog           = 1000
nstxout-compressed = 500

continuation     = yes
constraint_algorithm = lincs
constraints      = h-bonds
lincs_iter       = 2
lincs_order      = 4

tcoupl           = V-rescale
tc-grps          = SPI     TBM   TFS
tau_t            = 0.1     0.1   0.1
ref_t            = 300     300   300

Pcoupl       = C-rescale
pcoupltype       = isotropic
tau_p            = 5.0
ref_p            = 1.0
compressibility  = 4.5e-5

gen_vel          = no

ns_type     = grid
nstlist     = 10
rlist       = 1.0
rcoulomb    = 1.0
rvdw        = 1.0
coulombtype = PME
pme_order   = 4
fourierspacing  = 0.16
EOF

cat > nvt.mdp <<EOF
integrator       = md
dt               = 0.002
nsteps           = 2500000        ; 5 ns
nstxout          = 1000
nstvout          = 1000
nstenergy        = 1000
nstlog           = 1000
nstxout-compressed = 500

continuation     = no      ; use yes if continuing from previous run
constraint_algorithm = lincs
constraints      = h-bonds
lincs_iter       = 2
lincs_order      = 4

tcoupl           = V-rescale
tc-grps          = SPI     TBM   TFS
tau_t            = 0.1     0.1   0.1
ref_t            = 300     300   300

pcoupl           = no

gen_vel          = yes     ; use no if continuation = yes
gen_temp         = 300
gen_seed         = -1

ns_type     = grid
nstlist     = 10
rlist       = 1.0
rcoulomb    = 1.0
rvdw        = 1.0
coulombtype = PME
pme_order   = 4
fourierspacing  = 0.16

EOF


# Convert from PDB to mol2 with 3D
obabel input.pdb -O input3d.mol2 --gen3d

# Parametrize with Antechamber
antechamber -i input3d.mol2 -fi mol2 -o gaff.mol2 -fo mol2 -c bcc -s 2 -at gaff

# (Optional) check and create missing parameters
parmchk2 -i gaff.mol2 -f mol2 -o frcmod

# Convert to GROMACS with acpype
acpype -i gaff.mol2
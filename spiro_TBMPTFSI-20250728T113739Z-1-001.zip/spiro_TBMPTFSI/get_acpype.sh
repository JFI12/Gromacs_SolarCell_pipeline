module load OpenBabel/3.1.1-hpc1-gcc-2022a-eb
# Step 1: Load Anaconda
module load Anaconda/2023.09-0-hpc1
module load Miniforge/24.7.1-2-hpc1 
module load GROMACS/2024.2-mpi+omp-hpc1-g11
export OMP_NUM_THREADS=4

obabel -:"COC1=CC=C(C=C1)N(C2=CC=C(C=C2)OC)C3=CC4=C(C=C3)C5=C(C46C7=C(C=CC(=C7)N(C8=CC=C(C=C8)OC)C9=CC=C(C=C9)OC)C1=C6C=C(C=C1)N(C1=CC=C(C=C1)OC)C1=CC=C(C=C1)OC)C=C(C=C5)N(C1=CC=C(C=C1)OC)C1=CC=C(C=C1)OC" -O spiro.mol2 --gen3D
obabel -:"CC(C)(C)C1=CC=[N+](C=C1)C" -O tbmp.mol2 --gen3D
obabel -:"C(F)(F)(F)S(=O)(=O)[N-]S(=O)(=O)C(F)(F)F" -O tfsi.mol2 --gen3D



# Step 2: Initialize conda into current shell
eval "$(conda shell.bash hook)"

# Step 3: Create the environment (only once)
#conda create -n acpype-env -c conda-forge python=3.9 openbabel ambertools acpype -y
conda create -n acpype-clean -c conda-forge python=3.9 openbabel ambertools acpype -y
# Step 4: Activate the environment
conda activate acpype-clean
 
# Step 5: Confirm it worked
acpype -h
obabel -V


#Doesnt work
#acpype -i tbmp.mol2 -b tbmp -n 1 -c user
#acpype -i tfsi.mol2 -b tfsi -n -1 -c user
#acpype -i spiro.mol2 -b spiro -c user

#obabel spiro.mol2 -O spiro_opt.mol2 --gen3d --minimize -h
#acpype -i spiro_opt.mol2 -b spiro_bcc

#acpype -i spiro.mol2 -b spiro -c gas
#acpype -i tbmp.mol2 -b tbmp -n 1 -c gas
#acpype -i tfsi.mol2 -b tfsi -n -1 -c gas


###### try (acpype-clean) [x_melfi@sigma spiro_TBMPTFSI]$ 
#This takes several hours
#this took me 1.5 hours
obabel spiro.mol2 -O spiro_min.mol2 --minimize --ff MMFF94 --steps 250

#always delete the folder when rebuilding them
#this took me 1.3 hours
acpype -i spiro_min.mol2 -b spiro -n 0 -c bcc

acpype -i tbmp.mol2 -b tbmp -n 1 -c bcc
acpype -i tfsi.mol2 -b tfsi -n -1 -c bcc
#gmx_mpi editconf -f spiro.acpype/spiro_GMX.gro -o generated_files/spiro_GMX.pdb
#gmx_mpi editconf -f tbmp.acpype/tbmp_GMX.gro -o generated_files/tbmp_GMX.pdb
#gmx_mpi editconf -f tfsi.acpype/tfsi_GMX.gro -o generated_files/tfsi_GMX.pdb
"""
tolerance 2.0
filetype pdb
output mixture.pdb

structure ../spiro.acpype/spiro_NEW.pdb
  number 80
  inside box 0. 0. 0. 50. 50. 50.   # Make sure box is big enough!
  filetype gro
end structure

structure ../tbmp.acpype/tbmp_NEW.pdb
  number 20
  inside box 0. 0. 0. 50. 50. 50.   # Make sure box is big enough!
end structure

structure ../tfsi.acpype/tfsi_NEW.pdb
  number 20
  inside box 0. 0. 0. 50. 50. 50.   # Make sure box is big enough!
end structure"""
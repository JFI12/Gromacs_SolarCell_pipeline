import re

# Atomic masses dictionary (in g/mol)
atomic_masses = {
    'H': 1.008, 'C': 12.011, 'N': 14.007, 'O': 15.999,
    'F': 18.998, 'P': 30.974, 'S': 32.06, 'Cl': 35.45,
    'Br': 79.904, 'I': 126.90, 'Si': 28.085, # add more if needed
}

NA = 6.022e23  # Avogadro's number (mol⁻¹)

gro_file = "generated_files/mixture.gro"

total_mass_mol = 0.0  # total atomic mass in g/mol units
atom_count = 0


def get_element(atom_name):
 
    # Match 1 uppercase letter + optional lowercase letter at start of string
    match = re.match(r"^([A-Z][a-z]?)", atom_name)
    if match:
        return match.group(1)
    return None
with open(gro_file, "r") as f:
    lines = f.readlines()

# Last line contains box dimensions in nm (usually 3 values)
box_line = lines[-1].strip()
box_dims = list(map(float, box_line.split()))

# Calculate box volume in nm^3, then convert to cm^3 (1 nm^3 = 1e-21 cm^3)
volume_nm3 = 1.0
for v in box_dims:
    volume_nm3 *= v
volume_cm3 = volume_nm3 * 1e-21

# Parse atoms from line 3 up to the line before box dimensions
for line in lines[2:-1]:
    
    parts = line.split()

    if len(parts) < 5:
        continue  # skip malformed lines
   
    atom_name = parts[1]

    element = get_element(atom_name)
    
    if element and element in atomic_masses:
        total_mass_mol += atomic_masses[element]
        atom_count += 1
    else:
        print(f"Warning: Unknown element for atom name '{atom_name}'")

# Convert total mass from g/mol to grams using Avogadro's number
mass_g = total_mass_mol / NA

# Calculate density = mass / volume (g/cm³)
density = mass_g / volume_cm3

print(f"Total atoms counted: {atom_count}")
print(f"Total mass: {mass_g:.3e} g")
print(f"Box volume: {volume_cm3:.3e} cm³")
print(f"Estimated density: {density:.3f} g/cm³")

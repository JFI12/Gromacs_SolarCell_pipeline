from openff.toolkit.topology import Molecule
from openff.toolkit.engines.smirnoff import ForceField
from openff.toolkit.utils import RDKitToolkitWrapper

# Define charged TFSI as SMILES
tfsi = Molecule.from_smiles("C(F)(F)(F)S(=O)(=O)[N-]S(=O)(=O)C(F)(F)F", toolkit_registry=RDKitToolkitWrapper())
tfsi.generate_conformers()
tfsi.assign_partial_charges(partial_charge_method="am1bcc")

# Save to OpenMM format or GROMACS via InterMol
tfsi.to_file("tfsi.sdf", file_format="sdf")
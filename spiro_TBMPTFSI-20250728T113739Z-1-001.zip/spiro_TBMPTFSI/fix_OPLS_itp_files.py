import os
import re

# Create output directory if it doesn't exist
os.makedirs("generated_files", exist_ok=True)

# Mapping of known OPLS types
atom_type_map = {
    'opls_135': 'CT',
    'opls_145': 'CA',
    'opls_300': 'N2',
    'opls_x':   'OS',  # generic fallback for unknown O atoms
    'opls_140': 'HC',
    'opls_146': 'HA',
    'opls_503': 'NA',
    'opls_236': 'O',

    # Hydrogen type guess based on name
    **{f'H{i}': 'HA' for i in range(1, 100)},
    'H': 'HC', 'H1': 'HC', 'H2': 'HC', 'H3': 'HC',
}

# List of input files
input_files = [
    'spiro.acpype/spiro_GMX_OPLS.itp',
    'tbmp.acpype/tbmp_GMX_OPLS.itp',
    'tfsi.acpype/tfsi_GMX_OPLS.itp',
]

# Process each input file
for input_file in input_files:
    base = os.path.basename(input_file)
    output_file = f"generated_files/{base.replace('.itp', '_fixed.itp')}"

    with open(input_file, 'r') as f:
        lines = f.readlines()

    with open(output_file, 'w') as f:
        for line in lines:
            # Keep comments and empty lines unchanged
            if line.strip().startswith(';') or not line.strip():
                f.write(line)
                continue

            # Keep section headers untouched
            if '[ atoms ]' in line or '[ moleculetype ]' in line:
                f.write(line)
                continue

            # Match atom lines
            match = re.match(
                r'\s*(\d+)\s+(\S+)\s+(\d+)\s+(\S+)\s+(\S+)\s+(\d+)\s+([-0-9.Ee]+)\s+([0-9.Ee]+)', line
            )
            if match:
                atom_id = int(match.group(1))
                raw_type = match.group(2)
                res_id = match.group(3)
                res_name = match.group(4)
                atom_name = match.group(5)
                cgnr = int(match.group(6))
                charge = float(match.group(7))
                mass = float(match.group(8))

                # Fix type
                if raw_type.startswith('opls_'):
                    fixed_type = atom_type_map.get(raw_type, raw_type)
                elif raw_type == 'opls':
                    # Try by atom name
                    fixed_type = atom_type_map.get(atom_name, 'HC' if mass < 2 else 'CT')
                else:
                    fixed_type = raw_type  # preserve if already known

                # Format and write new line
                f.write(
                    f"{atom_id:>5} {fixed_type:<8}{res_id:>5} {res_name:<5}{atom_name:<8}{cgnr:>5} "
                    f"{charge:>10.6f} {mass:>10.5f}\n"
                )
            else:
                f.write(line)

print("Fixed .itp files saved in 'generated_files/'")

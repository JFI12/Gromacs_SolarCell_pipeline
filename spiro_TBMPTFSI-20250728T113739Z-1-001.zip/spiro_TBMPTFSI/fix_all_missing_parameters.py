import re
import sys
import os

def fix_param_block(lines, block_name, expected_func_type, param_count):
    inside_block = False
    fixed = []

    for line in lines:
        stripped = line.strip()

        if stripped.startswith(f"[ {block_name} ]"):
            inside_block = True
            fixed.append(line)
            continue
        elif inside_block and stripped.startswith("[") and not stripped.startswith(f"[ {block_name} ]"):
            inside_block = False

        if inside_block and not stripped.startswith(";") and ";" in line:
            code, comment = line.split(";", 1)
            tokens = code.strip().split()
            params = re.findall(r"[-+]?\d*\.\d+|\d+", comment)

            # Skip malformed lines
            required_tokens = 5 if block_name == "dihedrals" else 4
            if len(tokens) < required_tokens:
                fixed.append(line)
                continue

            # Add missing parameters if only funct is present
            if len(tokens) == required_tokens and len(params) >= param_count:
                new_tokens = tokens + params[:param_count]
                fixed_line = "{:<6}" * len(new_tokens) + "; " + comment.strip()
                fixed.append(fixed_line.format(*new_tokens) + "\n")
                continue

        fixed.append(line)
    return fixed

def fix_file(filename):
    if not os.path.exists(filename):
        print(f"❌ File not found: {filename}")
        sys.exit(1)

    with open(filename, "r") as f:
        lines = f.readlines()

    lines = fix_param_block(lines, "angles", expected_func_type=1, param_count=2)
    lines = fix_param_block(lines, "dihedrals", expected_func_type=9, param_count=3)
    lines = fix_param_block(lines, "impropers", expected_func_type=2, param_count=3)

    output_dir = "generated_files"
    os.makedirs(output_dir, exist_ok=True)
    output_file = os.path.join(output_dir, os.path.basename(filename))

    with open(output_file, "w") as f:
        f.writelines(lines)

    print(f"✅ Fixed file written to: {output_file}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python fix_all_missing_parameters.py yourfile.itp")
        sys.exit(1)

    fix_file(sys.argv[1])

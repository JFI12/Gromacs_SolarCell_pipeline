import os
import sys

# Map keywords in folder name to target residue names
resname_map = {
    "spiro": "SPI",
    "tbmp": "TBM",
    "tfsi": "TFS",
    # Add more mappings here
}

DEFAULT_OLD_RESNAME = "UNL"

def rename_residue_in_pdb(pdb_path, new_resname):
    with open(pdb_path, 'r') as f:
        lines = f.readlines()
    with open(pdb_path, 'w') as f:
        for line in lines:
            if line.startswith(("ATOM", "HETATM")):
                line = line[:17] + new_resname.ljust(3) + line[20:]
            f.write(line)

def rename_molecule_in_gro(gro_path, old_resname, new_resname):
    with open(gro_path, 'r') as f:
        lines = f.readlines()
    with open(gro_path, 'w') as f:
        for i, line in enumerate(lines):
            if i < 2 or len(line) < 10:
                f.write(line)
                continue
            molname = line[5:10].strip()
            if molname == old_resname:
                line = line[:5] + new_resname.ljust(5) + line[10:]
            f.write(line)

def rename_itp(itp_path, old_resname, new_resname, old_molname):
    with open(itp_path, 'r') as f:
        lines = f.readlines()

    output_lines = []
    in_moleculetype = False
    in_atoms = False

    for line in lines:
        stripped = line.strip()

        # Handle [ moleculetype ] section: replace molecule name line after header
        if stripped.startswith('[ moleculetype ]'):
            output_lines.append(line)
            in_moleculetype = True
            continue

        if in_moleculetype:
           
            # This line should be molecule name line (e.g. "spiro 3")
            if stripped and not stripped.startswith(';'):
                
                parts = line.split()
         #       print(f'line: {line}')
          #      print(f'old_molname: {old_molname}')
                if parts[0] == old_molname:
                    parts[0] = new_resname
                output_lines.append('    '.join(parts) + '\n')
                in_moleculetype = False
            else:
                output_lines.append(line)
            continue

        # Detect [ atoms ] section
        if stripped.startswith('[ atoms ]'):
            output_lines.append(line)
            in_atoms = True
            continue

        # Detect leaving [ atoms ] section by encountering a new section header
        if in_atoms:
            if stripped.startswith('[') and not stripped.startswith('[ atoms ]'):
                in_atoms = False
                output_lines.append(line)
                continue

            # Inside atoms section: replace residue name (4th column)
            if stripped == '' or stripped.startswith(';'):
                output_lines.append(line)
            else:
                parts = line.split()
                if len(parts) >= 6:
                    if parts[3] == old_resname:
                        parts[3] = new_resname
                    new_line = '  '.join(parts) + '\n'
                    output_lines.append(new_line)
                else:
                    output_lines.append(line)
            continue

        # Otherwise, copy line as-is
        output_lines.append(line)

    with open(itp_path, 'w') as f:
        f.writelines(output_lines)

def process_folder(folder_path):
    folder_key = os.path.basename(folder_path).lower()
    new_resname = None
    for key, val in resname_map.items():
        if key in folder_key:
            new_resname = val
            break

    if new_resname is None:
        print(f"❌ No residue mapping found for folder '{folder_path}', skipping.")
        return

    print(f"🔄 Processing folder '{folder_path}' with residue name: {new_resname}")

    for file in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file)
        if file.endswith(".pdb"):
            print(f"  📄 Renaming residue in: {file}")
            rename_residue_in_pdb(file_path, new_resname)
        elif file.endswith(".gro"):
            print(f"  📄 Renaming molecule in: {file}")
            rename_molecule_in_gro(file_path, DEFAULT_OLD_RESNAME, new_resname)
        elif file.endswith(".itp"):
            print(f"  📄 Renaming entries in: {file}")
            old_name = folder_key.split(".")[0]
            rename_itp(file_path, DEFAULT_OLD_RESNAME, new_resname, old_name)
        else:
            continue

def main():
    if len(sys.argv) < 2:
        print("Usage: python rename_residues.py folder1 folder2 ...")
        return

    for folder in sys.argv[1:]:
        if os.path.isdir(folder):
            process_folder(folder)
        else:
            print(f"❌ Not a directory: {folder}")

if __name__ == "__main__":
    main()

import re

# Atomic masses dictionary (in g/mol)
atomic_masses = {
    'H': 1.008, 'C': 12.011, 'N': 14.007, 'O': 15.999,
    'F': 18.998, 'P': 30.974, 'S': 32.06, 'Cl': 35.45,
    'Br': 79.904, 'I': 126.90, 'Si': 28.085,
}

NA = 6.022e23  # Avogadro's number (mol⁻¹)

gro_file = "generated_files/boxed.gro"  # Change this path if needed

total_mass_mol = 0.0  # Total atomic mass in g/mol
atom_count = 0


def get_element(atom_name):
    # Extract the element symbol from atom name
    match = re.match(r"^([A-Z][a-z]?)", atom_name)
    if match:
        return match.group(1)
    return None


with open(gro_file, "r") as f:
    lines = f.readlines()

# Get box dimensions from the last line (assumes 3 values: x y z in nm)
box_line = lines[-1].strip()
box_dims = list(map(float, box_line.split()))

# Compute box volume in nm³, then convert to cm³ (1 nm³ = 1e-21 cm³)
volume_nm3 = box_dims[0] * box_dims[1] * box_dims[2]
volume_cm3 = volume_nm3 * 1e-21

# Process atoms from line 3 to the second-last line
for line in lines[2:-1]:
    parts = line.split()
    if len(parts) < 5:
        continue  # Skip malformed lines
    atom_name = parts[1]
    element = get_element(atom_name)
    if element and element in atomic_masses:
        total_mass_mol += atomic_masses[element]
        atom_count += 1
    else:
        print(f"Warning: Unknown element for atom name '{atom_name}'")

# Convert total mass to grams using Avogadro's number
mass_g = total_mass_mol / NA

# Compute density in g/cm³
density = mass_g / volume_cm3

print(f"File: {gro_file}")
print(f"Total atoms counted: {atom_count}")
print(f"Total mass: {mass_g:.3e} g")
print(f"Box volume: {volume_cm3:.3e} cm³")
print(f"Estimated density: {density:.3f} g/cm³")
print("Can be lower than the mixture.gro because of added space")
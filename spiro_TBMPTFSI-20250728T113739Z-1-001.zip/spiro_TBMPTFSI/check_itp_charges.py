import sys
import re
from pathlib import Path

def parse_itp_charge(file_path):
    with open(file_path) as f:
        lines = f.readlines()

    in_atoms = False
    total_charge = 0.0
    atom_lines = []

    for line in lines:
        
        if line.strip().startswith('[ atoms ]'):
            print(f'line: {line}')
            in_atoms = True
            continue
        if in_atoms:
            if line.strip().startswith('['):  # next section
                break
            if line.strip().startswith(';') or line.strip() == '':
                continue
            atom_lines.append(line)

    for line in atom_lines:
        fields = line.split()
        try:
            charge = float(fields[6])  # GROMACS format: [nr type resnr residue atom cgnr q m]
            total_charge += charge
        except (IndexError, ValueError):
            print(f"⚠️  Skipping malformed line in {file_path}: {line.strip()}")

    return round(total_charge, 4)

if __name__ == "__main__":
    for itp_file in sys.argv[1:]:
        charge = parse_itp_charge(itp_file)
        print(f"{itp_file}: Total charge = {charge:+.4f}")

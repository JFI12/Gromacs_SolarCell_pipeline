import matplotlib.pyplot as plt

def read_xvg(filename):
    time = []
    data = []
    with open(filename) as f:
        for line in f:
            if line.startswith('#') or line.startswith('@'):
                continue
            parts = line.split()
            time.append(float(parts[0]))
            data.append(float(parts[1]))
    return time, data

# List of files with corresponding titles and y-axis labels
xvg_files = [
   # ('generated_files/temperature_TFS.xvg', 'Temperature vs Time (TFS)', 'Temperature (K)'),
  #  ('generated_files/temperature_SPI.xvg', 'Temperature vs Time (SPI)', 'Temperature (K)'),
   # ('generated_files/temperature_TBM.xvg', 'Temperature vs Time (TBM)', 'Temperature (K)'),
   # ('generated_files/com_TFS.xvg', 'Center of Mass vs Time (TFSI)', 'Distance (nm)'),
   # ('generated_files/rmsd_TFS.xvg', 'RMSD vs Time (TFSI)', 'RMSD (nm)'),
  #  ('generated_files/rmsd_SPI.xvg', 'RMSD vs Time (SPI)', 'RMSD (nm)'),
 #('generated_files/temperature_decending.xvg', 'Temperature vs Time (system)', 'Temperature (K)'),
  #('generated_files/volume.xvg', 'volume vs Time (system)', 'volume (nm^3)'),
('generated_files/density.xvg', 'density vs Time (system)', 'density (kg/m^3)'),
('generated_files/density_comp.xvg', 'density vs Time (system)', 'density (kg/m^3)')
]

# Plot each file in a separate figure
for file_path, title, ylabel in xvg_files:
    time, data = read_xvg(file_path)
    plt.figure()
    plt.plot(time, data)
    plt.xlabel('Time (ps)')
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True)
    plt.tight_layout()

plt.show()

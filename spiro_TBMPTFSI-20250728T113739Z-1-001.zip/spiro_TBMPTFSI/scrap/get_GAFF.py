from openff.toolkit.topology import Molecule
from openff.toolkit.typing.engines.smirnoff import ForceField
from openmm.app import Simulation, Topology, PDBFile
from openmm import System

mol = Molecule.from_file("spiro.sdf")  # or mol2 or pdb
mol.generate_conformers()
ff = ForceField("openff-2.0.0.offxml")  # or 2.1.0
system = ff.create_openmm_system(mol.to_topology())

# Save to OpenMM format and convert to GROMACS using ParmEd:
from openmm import app
import parmed as pmd

pdb = mol.to_file("spiro.pdb", file_format="pdb")
modeller = app.Modeller(app.Topology(), [])
system = ff.create_openmm_system(mol.to_topology())
top = pmd.openmm.load_topology(mol.to_topology().to_openmm(), system)

top.save("spiro.top")
top.save("spiro.gro")
top.save("spiro.itp")

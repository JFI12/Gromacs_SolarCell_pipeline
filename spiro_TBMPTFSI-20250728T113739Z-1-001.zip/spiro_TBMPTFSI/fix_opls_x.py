import re
import sys
import os

# Hardcoded manual fixes for unmatched atoms
manual_overrides = {
    # Oxygen examples (ether)
    'o': 'opls_154',
    'o1': 'opls_154',
    'o2': 'opls_154',
    'o3': 'opls_154',
    'o4': 'opls_154',
    'o5': 'opls_154',
    'o6': 'opls_154',
    'o7': 'opls_154',

    # Carbon examples (alkanes)
    'c17': 'opls_135',
    'c20': 'opls_135',
    'c22': 'opls_135',
    'c24': 'opls_135',
    'c43': 'opls_135',

    # ✅ Fluorine (typical for -CF3 groups or TFSI)
    'f': 'opls_180',
    'f1': 'opls_180',
    'f2': 'opls_180',
    'f3': 'opls_180',
    'f4': 'opls_180',
    'f5': 'opls_180',

    # ✅ Sulfur (e.g. sulfonyl groups in TFSI)
    's': 'opls_235',
    's1': 'opls_235',

    # ✅ Nitrogen (e.g. in TFSI core)
    'n': 'opls_232',
}


def parse_suggestions(itp_lines):
    suggestions = {}
    for line in itp_lines:
        if line.startswith(";") and "Possible_Alternatives" in line:
            # e.g., ; ha:HA:opls_146: []
            parts = line[1:].split(":")
            if len(parts) >= 3:
                ac_atom = parts[0].strip().lower()
                opls_type = parts[2].strip()
                suggestions[ac_atom] = opls_type
    return suggestions

def fix_opls_atoms(itp_lines, suggestions):
    fixed_lines = []
    inside_atoms = False
    for line in itp_lines:
        stripped = line.strip()
        if stripped.startswith("[ atoms ]"):
            inside_atoms = True
            fixed_lines.append(line)
            continue
        elif stripped.startswith("[") and inside_atoms:
            inside_atoms = False

        if inside_atoms and not stripped.startswith(";") and "opls_x" in line:
            parts = line.split()
            if len(parts) >= 5:
                atom_name = parts[4].lower()
                guess = suggestions.get(atom_name) or manual_overrides.get(atom_name)
                if guess:
                    print(f"✔ Replacing atom '{atom_name}' type 'opls_x' → '{guess}'")
                    parts[1] = guess
                    line = "{:<6} {:<10} {:<4} {:<4} {:<6} {:<6} {:<12} {:<10} ; {}\n".format(
                        parts[0], parts[1], parts[2], parts[3], parts[4], parts[5],
                        parts[6], parts[7], " ".join(parts[8:]) if len(parts) > 8 else ""
                    )
                else:
                    print(f"⚠ Could not find replacement for atom '{atom_name}' → left as 'opls_x'")
        fixed_lines.append(line)
    return fixed_lines

def main():
    if len(sys.argv) != 2:
        print("Usage: python fix_opls_x.py yourfile.itp")
        return

    filename = sys.argv[1]
    if not os.path.exists(filename):
        print(f"❌ File not found: {filename}")
        return

    with open(filename, "r") as f:
        itp_lines = f.readlines()

    suggestions = parse_suggestions(itp_lines)
    fixed_itp = fix_opls_atoms(itp_lines, suggestions)

    output_dir = "generated_files"
    os.makedirs(output_dir, exist_ok=True)
    output_file = os.path.join(output_dir, os.path.basename(filename))

    with open(output_file, "w") as f:
        f.writelines(fixed_itp)

    print(f"✅ Fixed file saved as: {output_file}")

if __name__ == "__main__":
    main()

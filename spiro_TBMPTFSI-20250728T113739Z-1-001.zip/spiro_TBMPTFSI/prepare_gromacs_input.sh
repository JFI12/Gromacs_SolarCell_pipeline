#!/bin/bash
export OMP_NUM_THREADS=8
set -e

module load GROMACS/2024.2-mpi+omp-hpc1-g11

mkdir -p generated_files
cd generated_files

# Copy ligand files (topology and structures pre-prepared by ACPYPE)
#cp ../spiro.acpype/spiro_GMX_OPLS.gro .
cp ../spiro.acpype/spiro_GMX.itp .

cp ../tbmp.acpype/tbmp_GMX.itp .

cp ../tfsi.acpype/tfsi_GMX.itp .
cp ../spiro.acpype/spiro_NEW.pdb .
cp ../tbmp.acpype/tbmp_NEW.pdb .
cp ../tfsi.acpype/tfsi_NEW.pdb .

: <<'END_COMMENT'
#python3 ../rename_packmol_input.py spiro.acpype tfsi.acpype tbmp.acpype
#python3 ../fix_OPLS_itp_files.py

packmol < packmol_input.inp 
# Assume Packmol output file is mixture.pdb
# Convert mixture.pdb to mixture.gro for GROMACS
#gmx editconf -f ../mixture.pdb -o mixture.gro

gmx_mpi editconf -f mixture.pdb -o mixture.gro -box 5 5 5

./../fix_itp_files.sh
END_COMMENT
# Merge topologies (GAFF/AMBER-based from ACPYPE)
: <<'END_COMMENT'
This is a multiline comment.
It won't be executed.
Variables like $FOO will not be expanded.

[ atomtypes ]
;name   bond_type     mass     charge   ptype   sigma         epsilon       Amb
 c3       c3          0.00000  0.00000   A     3.39771e-01   4.51035e-01 ; 1.91  0.1078
 os       os          0.00000  0.00000   A     3.15610e-01   3.03758e-01 ; 1.77  0.0726
 ca       ca          0.00000  0.00000   A     3.31521e-01   4.13379e-01 ; 1.86  0.0988
 nh       nh          0.00000  0.00000   A     3.18995e-01   8.99560e-01 ; 1.79  0.2150
 cp       cp          0.00000  0.00000   A     3.31521e-01   4.13379e-01 ; 1.86  0.0988
 c5       c5          0.00000  0.00000   A     3.39771e-01   4.51035e-01 ; 1.91  0.1078
 h1       h1          0.00000  0.00000   A     2.42200e-01   8.70272e-02 ; 1.36  0.0208
 ha       ha          0.00000  0.00000   A     2.62548e-01   6.73624e-02 ; 1.47  0.0161
 na       na          0.00000  0.00000   A     3.20581e-01   8.54373e-01 ; 1.80  0.2042
 hc       hc          0.00000  0.00000   A     2.60018e-01   8.70272e-02 ; 1.46  0.0208
 h4       h4          0.00000  0.00000   A     2.53639e-01   6.73624e-02 ; 1.42  0.0161
 f        f           0.00000  0.00000   A     3.03422e-01   3.48109e-01 ; 1.70  0.0832
 s6       s6          0.00000  0.00000   A     4.05840e-01   2.56898e-01 ; 2.28  0.0614
 o        o           0.00000  0.00000   A     3.04812e-01   6.12119e-01 ; 1.71  0.1463
 ne       ne          0.00000  0.00000   A     3.38417e-01   3.93714e-01 ; 1.90  0.0941
 sy       sy          0.00000  0.00000   A     4.05840e-01   2.56898e-01 ; 2.28  0.0614
END_COMMENT

cat > topol.top <<EOF
; Include the forcefield — only once!
#include "amber99.ff/forcefield.itp"

[ atomtypes ]
;name   bond_type     mass     charge   ptype   sigma         epsilon       Amb
 c3       c3          0.00000  0.00000   A     3.39771e-01   4.51035e-01 ; 1.91  0.1078
 os       os          0.00000  0.00000   A     3.15610e-01   3.03758e-01 ; 1.77  0.0726
 ca       ca          0.00000  0.00000   A     3.31521e-01   4.13379e-01 ; 1.86  0.0988
 nh       nh          0.00000  0.00000   A     3.18995e-01   8.99560e-01 ; 1.79  0.2150
 cp       cp          0.00000  0.00000   A     3.31521e-01   4.13379e-01 ; 1.86  0.0988
 c5       c5          0.00000  0.00000   A     3.39771e-01   4.51035e-01 ; 1.91  0.1078
 h1       h1          0.00000  0.00000   A     2.42200e-01   8.70272e-02 ; 1.36  0.0208
 ha       ha          0.00000  0.00000   A     2.62548e-01   6.73624e-02 ; 1.47  0.0161
 na       na          0.00000  0.00000   A     3.20581e-01   8.54373e-01 ; 1.80  0.2042
 hc       hc          0.00000  0.00000   A     2.60018e-01   8.70272e-02 ; 1.46  0.0208
 h4       h4          0.00000  0.00000   A     2.53639e-01   6.73624e-02 ; 1.42  0.0161
 f        f           0.00000  0.00000   A     3.03422e-01   3.48109e-01 ; 1.70  0.0832
 s6       s6          0.00000  0.00000   A     4.05840e-01   2.56898e-01 ; 2.28  0.0614
 o        o           0.00000  0.00000   A     3.04812e-01   6.12119e-01 ; 1.71  0.1463
 ne       ne          0.00000  0.00000   A     3.38417e-01   3.93714e-01 ; 1.90  0.0941
 sy       sy          0.00000  0.00000   A     4.05840e-01   2.56898e-01 ; 2.28  0.0614


; Now include the molecule topologies
#include "spiro_GMX.itp"
#include "tbmp_GMX.itp"
#include "tfsi_GMX.itp"

[ system ]
; Description
My cool simulation

[ molecules ]
; Compound     #mols
SPI           100
TBM           20
TFS           20

EOF


# Define box and center molecules (if needed)
gmx_mpi editconf -f mixture.gro -o boxed.gro -bt cubic -c -d 1.0
cp mixture.gro boxed.gro
# Optional: add water (for solid-state you might skip this)
#gmx_mpi solvate -cp boxed.gro -cs spc216.gro -o solvated.gro -p topol.top


echo "✅ Spiro-OMeTAD + TBMP⁺ + TFSI⁻ system ready for simulation."

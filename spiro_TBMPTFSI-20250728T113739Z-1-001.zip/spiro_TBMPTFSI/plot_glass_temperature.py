import numpy as np
import matplotlib.pyplot as plt

# Load XVG files (skip header lines starting with @ or #)
def load_xvg(filename):
    data = []
    with open(filename) as f:
        for line in f:
            if not line.startswith(('@', '#')):
                data.append([float(x) for x in line.split()])
    return np.array(data)

temp_data = load_xvg("generated_files/temperature.xvg")
vol_data = load_xvg("generated_files/volume.xvg")

# Interpolate volume at temperature times if needed
from scipy.interpolate import interp1d
interp_volume = interp1d(vol_data[:, 0], vol_data[:, 1], fill_value="extrapolate")
volume_at_temp = interp_volume(temp_data[:, 0])

plt.plot(temp_data[:, 1], volume_at_temp, 'o-')
plt.xlabel("Temperature (K)")
plt.ylabel("Volume (nm³)")
plt.title("Volume vs Temperature")
plt.grid(True)
plt.show()

#!/bin/bash

for itpfile in *.itp; do
  echo "Processing $itpfile ..."
  tmpfile=$(mktemp)

  # Remove [ atomtypes ] and [ moleculetype ] sections
  awk '
    BEGIN { skip=0 }
    /^\[ atomtypes \]/  { skip=1; next }
    /^\[.*\]/ { skip=0 }
    skip==0 { print }
  ' "$itpfile" > "$tmpfile"

  mv "$tmpfile" "$itpfile"
done

echo "Done removing [ atomtypes ] and [ moleculetype ] sections."

import os
import numpy as np
import matplotlib.pyplot as plt

# Base directory
base_folder = "generated_files"

# Temperature points
temps = [600, 550, 500, 450, 400, 375, 350, 330, 310, 290, 270]

avg_temps = []
avg_volumes = []

def extract_avg_from_xvg(filepath):
    """Extract average value from .xvg file, skipping comments and headers"""
    try:
        with open(filepath, 'r') as f:
            data = [
                list(map(float, line.strip().split()))
                for line in f
                if not line.startswith(("#", "@")) and len(line.strip().split()) == 2
            ]
        if data:
            
            values = [v[1] for v in data]
            avg = sum(values) / len(values)
            print(f"  avg {avg} ")
            return sum(values) / len(values)
    
    except Exception as e:
        print(f"Error reading {filepath}: {e}")
    return None

for T in temps:
    folder = os.path.join(base_folder, f"T_{T}")
    temp_file = os.path.join(folder, "temperature.xvg")
    vol_file = os.path.join(folder, "volume.xvg")

    print(f"Processing T = {T} K")

    if not os.path.isfile(temp_file) or not os.path.isfile(vol_file):
        print(f"  Skipping {T} K: Missing .xvg files")
        continue
    print(f'temp: {temp_file}')
    avg_temp = extract_avg_from_xvg(temp_file)
    avg_vol = extract_avg_from_xvg(vol_file)
    print(f'temp: {avg_temp}')
    if avg_temp is None or avg_vol is None:
        print(f"  Skipping {T} K due to error reading values")
        continue

    avg_temps.append(avg_temp)
    avg_volumes.append(avg_vol)

# Convert to arrays and sort by temperature
avg_temps = np.array(avg_temps)
avg_volumes = np.array(avg_volumes)
sorted_indices = np.argsort(avg_temps)

avg_temps = avg_temps[sorted_indices]
avg_volumes = avg_volumes[sorted_indices]


# Plot
plt.figure(figsize=(8, 6))
plt.plot(avg_temps, avg_volumes, marker='o')
plt.xlabel("Temperature (K)")
plt.ylabel("Average Volume (nm³)")
plt.title("Volume vs Temperature")
plt.grid(True)
plt.tight_layout()
plt.savefig("volume_vs_temperature.png", dpi=300)
plt.show()
